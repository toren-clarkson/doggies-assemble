package local.dogwand;

import java.util.*;
import org.bukkit.util.Vector;

/** Stable spaced destinations, and a bounded front line around each enemy. */
public final class PackFormation {
    public static final int FIGHTERS=8;
    private PackFormation(){}
    public static List<Vector> stay(int count){
        if(count<=0)return List.of();int side=(int)Math.ceil(Math.sqrt(count));List<Vector> cells=new ArrayList<>();
        for(int x=-side;x<=side;x++)for(int z=-side;z<=side;z++)cells.add(new Vector(x*1.8,0,z*1.8));
        cells.sort(Comparator.comparingDouble(Vector::lengthSquared).thenComparingDouble(Vector::getX).thenComparingDouble(Vector::getZ));return List.copyOf(cells.subList(0,count));
    }
    public static double radius(int count){return stay(Math.max(1,count)).stream().mapToDouble(Vector::length).max().orElse(0)+.55;}
    public static Vector combat(int slot){
        if(slot<FIGHTERS){double angle=slot*Math.PI*2/FIGHTERS;return new Vector(Math.cos(angle)*1.1,0,Math.sin(angle)*1.1);}
        int reserve=slot-FIGHTERS;double angle=reserve*2.399963229728653,radius=3+1.2*Math.sqrt(reserve);return new Vector(Math.cos(angle)*radius,0,Math.sin(angle)*radius);
    }
}
