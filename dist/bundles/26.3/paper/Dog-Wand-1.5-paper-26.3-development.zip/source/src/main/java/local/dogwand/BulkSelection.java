package local.dogwand;

/** One pending selection, confirmed only by releasing sneak. */
public final class BulkSelection {
    private BulkSelection(){}
    public static int percent(int clicks){return clicks>=1&&clicks<=5?120-clicks*20:0;}
    public static int count(int free,int percent){return percent<=0?0:(int)Math.ceil(free*Math.min(percent,100)/100.0);}
}
